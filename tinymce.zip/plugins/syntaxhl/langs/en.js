tinyMCE.addI18n('en.syntaxhl',{
	desc : 'Insert code using Syntaxhighlighter'
});
