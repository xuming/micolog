tinyMCE.addI18n('ch.advhr_dlg',{
width:"\u5BBD",
size:"\u957F",
noshade:"\u9634\u5F71"
});